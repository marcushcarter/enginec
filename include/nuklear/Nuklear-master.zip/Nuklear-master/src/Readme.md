File Packer:
------------
- On Linux/Mac just run ./paq.sh > ../nuklear.h
- On Windows just run paq.bat
